#include "stm32f10x.h"                  // Device header
#include "OLED.h"
#include "Console_Usart.h"
#include "shell.h"

Shell shell;
char shell_buffer[128];
volatile uint8_t rx_data;

signed short _shell_read(char *data , unsigned short len)
{
	if (rx_data!= 0)
	{
		*data = rx_data;
		rx_data = 0;
		return 1;
	}
	return 0;
}
signed short _shell_write(char *data , unsigned short len)
{
	for (unsigned short i = 0; i < len; i++)
	{
		usart_send_byte((uint8_t)data[i]);
	}
	return len;
}

static void usart_rx_handler(uint8_t data)
{
	rx_data = data;
}

int main(void)
{
	borad_init();
	usart_init();
	usart_set_callback(usart_rx_handler);

	shell.read = _shell_read;
	shell.write = _shell_read;
	shellInit(&shell, shell_buffer, sizeof(shell_buffer));
	while(1)
	{
		shellTask(&shell);
	}
}
