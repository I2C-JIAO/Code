#ifndef __LED_H
#define __LED_H

void LED_Init(void);
uint8_t LED_ON(void);
uint8_t LED_OFF(void);
void LED_Turn(void);
#endif
