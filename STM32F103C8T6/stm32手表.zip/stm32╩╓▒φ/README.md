# 多功能STM32手表

展示：




# 手表特点
* 0v ~ +20v的电压测量（其实可以更高）
* 0v ~ +20v的示波器（开发中）
* TF存储卡音乐播放，简单向文件夹内拷文件即可
* YX5200-24ss硬解码MP3芯片播放，dac输出分辨率可达24位，音质优良，可外放
* 流畅的切换和过渡动画
* 搭载w25q128存储芯片，可流畅播放视频，视频可自定义烧录
* 一个康威生命游戏（有玩家可操作）
* 一个反cos&sin计算（不知道为什么就被留下了）
* 亮度调节，在弹出窗口中调节亮度值可以实时改变当前亮度值


# 展示视频
（待更新）


# 参考
* UI：
  1. B站用户，江协科技：        https://www.bilibili.com/video/BV1EN41177Pc/
  2. B站用户，加油哦大灰狼： https://www.bilibili.com/video/BV1Xc411x7vQ/
  3.  Github，音游玩的人    ：https://github.com/RQNG?tab=repositories


