#ifndef __VOLTAGE_MEA_H
#define __VOLTAGE_MEA_H
	
void voltage_mt(void);
void voltage_waveform(void);


#endif

